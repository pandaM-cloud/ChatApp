
package registrationloginapp;

import java.util.Scanner;
import java.util.regex.Pattern;


public class RegistrationLoginApp {

    public static void main(String[] commandLineArguments) {

        Scanner consoleReader = new Scanner(System.in);
        Login accountHandler = new Login();

        System.out.println("_____USER REGISTRATION AND LOGIN APP_______");
        

       
        System.out.println("\n--- REGISTRATION ---");

     //firstname
        String capturedFirstName;
        while (true) {
            System.out.print("Enter your first name: ");
            capturedFirstName = consoleReader.nextLine().trim();
            if (!capturedFirstName.isEmpty()) {
                break;
            }
            System.out.println("First name cannot be blank; please try again.");
        }

        // Last name 
        String capturedLastName;
        while (true) {
            System.out.print("Enter your last name: ");
            capturedLastName = consoleReader.nextLine().trim();
            if (!capturedLastName.isEmpty()) {
                break;
            }
            System.out.println("Last name cannot be blank; please try again.");
        }


        String capturedUserName;
        while (true) {
            System.out.print("Enter a username: ");
            capturedUserName = consoleReader.nextLine().trim();

            if (accountHandler.checkUserName(capturedUserName)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; " + "please ensure that your username contains an " + "underscore and is no more than five characters in length.");
            }
        }


        String capturedPassword;
        while (true) {
            System.out.print("Enter a password: ");
            capturedPassword = consoleReader.nextLine();

            if (accountHandler.checkPasswordComplexity(capturedPassword)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; " + "please ensure that the password contains at least " + "eight characters, a capital letter, a number, and a " + "special character.");
            }
        }

        
        //Cell phone
        String capturedCellPhone;
        while (true) {
            System.out.print("Enter your South African cell phone number: ");
            capturedCellPhone = consoleReader.nextLine().trim();

            if (accountHandler.checkCellPhoneNumber(capturedCellPhone)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted " + "or does not contain international code.");
            }
        }

        // Store the validated
        String registrationOutcome = accountHandler.registerUser(
                capturedFirstName,
                capturedLastName,
                capturedUserName,
                capturedPassword,
                capturedCellPhone);

        System.out.println("\n" + registrationOutcome);

        //LOGIN 
        System.out.println("\n--- LOGIN ---");

        boolean userIsAuthenticated = false;
        while (!userIsAuthenticated) {

            System.out.print("Username: ");
            String loginUserNameAttempt = consoleReader.nextLine().trim();

            System.out.print("Password: ");
            String loginPasswordAttempt = consoleReader.nextLine();

            userIsAuthenticated = accountHandler.loginUser(loginUserNameAttempt, loginPasswordAttempt);
            System.out.println(accountHandler.returnLoginStatus(userIsAuthenticated));

            if (!userIsAuthenticated) {
                System.out.print("Would you like to try again? (yes/no): ");
                String retryChoice = consoleReader.nextLine().trim().toLowerCase();
                if (retryChoice.startsWith("n")) {
                    System.out.println("Exiting the application. Goodbye.");
                    break;
                }
            }
        }

        consoleReader.close();
    }
}





class Login {

    //Stored account details captured 
    private String storedFirstName;
    private String storedLastName;
    private String storedUserName;
    private String storedPassword;
    private String storedCellPhone;

    
    private static final Pattern PASSWORD_RULE_PATTERN = Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$");

    
    private static final Pattern CELLPHONE_RULE_PATTERN = Pattern.compile("^\\+[0-9]{1,3}[0-9]{1,10}$");

    
    public boolean checkUserName(String userNameToVerify) {
        if (userNameToVerify == null) {
            return false;
        }
        return userNameToVerify.contains("_") && userNameToVerify.length() <= 5;
    }

    public boolean checkPasswordComplexity(String passwordToVerify) {
        if (passwordToVerify == null) {
            return false;
        }
        return PASSWORD_RULE_PATTERN.matcher(passwordToVerify).matches();
    }

    public boolean checkCellPhoneNumber(String cellPhoneToVerify) {
        if (cellPhoneToVerify == null) {
            return false;
        }
        return CELLPHONE_RULE_PATTERN.matcher(cellPhoneToVerify).matches();
    }

    public String registerUser(String newFirstName,
                               String newLastName,
                               String newUserName,
                               String newPassword,
                               String newCellPhone) {

        if (!checkUserName(newUserName)) {
            return "Username is not correctly formatted; please ensure that your " + "username contains an underscore and is no more than five " + "characters in length.";
        }

        if (!checkPasswordComplexity(newPassword)) {
            return "Password is not correctly formatted; please ensure that the " + "password contains at least eight characters, a capital " + "letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(newCellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain " + "international code.";
        }

        this.storedFirstName = newFirstName;
        this.storedLastName = newLastName;
        this.storedUserName = newUserName;
        this.storedPassword = newPassword;
        this.storedCellPhone = newCellPhone;

        return "Registration successful. Username, password and cell phone " + "number have all been captured.";
    }

  //Passwprd on login
    public boolean loginUser(String userNameAttempt, String passwordAttempt) {
        if (storedUserName == null || storedPassword == null) {
            return false;
        }
        return storedUserName.equals(userNameAttempt)
                && storedPassword.equals(passwordAttempt);
    }

    //Welcome message
    public String returnLoginStatus(boolean authenticationResult) {
        if (authenticationResult) {
            return "Welcome " + storedFirstName + ", " + storedLastName+ " it is great to see you.";
        }
        return "Username or password incorrect, please try again.";
    }

    // Accessor used for testing purposes. 
    public String getStoredCellPhone() {
        return storedCellPhone;
    }
}
